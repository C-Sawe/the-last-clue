## CP1: Bezier, splines, evidence board and Case File panel (Latiffa)

See `MY_WORK_EXPLAINED.md` in my package for how each algorithm works.

**How to test:** `bash scripts/render_all.sh`, then open the images in `output/`.

Closes #4
Closes #22
Closes #23
Closes #24
Closes #25
