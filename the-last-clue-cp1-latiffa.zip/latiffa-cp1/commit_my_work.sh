#!/usr/bin/env bash
# Commits Latiffa's Checkpoint 1 work to the "latiffa" branch, one step per issue,
# under YOUR OWN git identity. Run it from the root of your clone of the-last-clue:
#
#     cd the-last-clue
#     bash ../latiffa-cp1/commit_my_work.sh
#     bash ../latiffa-cp1/commit_my_work.sh docs   # AFTER Sudheysi's PR is merged too
#
set -euo pipefail
PKG="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/files"
MODE="${1:-code}"

[[ -f CMakeLists.txt && -d .git ]] || { echo "Run this from the root of the-last-clue repository."; exit 1; }
EMAIL="$(git config user.email || true)"
[[ -n "$EMAIL" ]] || { echo "Set your identity first:  git config user.name \"Your Name\"  and  git config user.email \"your-github-email\""; exit 1; }
echo "Committing as: $(git config user.name) <$EMAIL>  (must be the email on your GitHub account)"

git fetch origin
git switch latiffa 2>/dev/null || git switch -c latiffa --track origin/latiffa
[[ -z "$(git status --porcelain)" ]] || { echo "You have uncommitted changes - commit or stash them first."; exit 1; }
git merge --no-edit origin/main

if [[ ! -f src/polygon/fill.cpp ]]; then
  echo "Alvin's polygon/fill code is not in main yet - your demos need it."
  echo "Wait until Alvin's pull request is merged, then run this again."
  exit 1
fi
step() {  # step "message" files...
  local msg="$1"; shift
  for f in "$@"; do
    for src in "$PKG"/$f; do
      local rel="${src#$PKG/}"
      mkdir -p "$(dirname "$rel")"; cp "$src" "$rel"; git add "$rel"
    done
  done
  if git diff --cached --quiet; then echo "  (already committed) $msg"; else git commit -q -m "$msg" && echo "  committed: $msg"; fi
}

if [[ "$MODE" == "code" ]]; then
  step "Implement Bezier curves with de Casteljau's algorithm (#22)" "src/curves/bezier.cpp" "demos/07_bezier.cpp"
  step "Implement Catmull-Rom splines (#23)" "src/curves/spline.cpp" "demos/08_spline.cpp"
  step "Add evidence board with Bezier strings and spline handwriting (#24)" "src/scenes/evidence_board.cpp" "demos/15_evidence_board.cpp"
  step "Add Case File panel and full game layout (#25)" "src/scenes/case_file.cpp" "demos/16_full_layout.cpp"
fi

if [[ "$MODE" == "docs" ]]; then
  if [[ ! -f src/polygon/clip.cpp ]]; then
    echo "Sudheysi's clipping work is not in main yet - the README describes it, so wait for that PR first."; exit 1
  fi
  step "Finalise README for Checkpoint 1 (#26)" "README.md"
  step "Add Checkpoint 1 screenshots and evidence PDF (#27)" "docs/screenshots/*" "docs/checkpoint1_screenshots.pdf"
fi
echo
if command -v cmake >/dev/null; then
  echo "Building and rendering to check everything works..."
  bash scripts/render_all.sh | tail -3 || echo "Build failed - send the error to Caleb before pushing."
else
  echo "cmake not found - skipping the build check (install CMake to run the demos)."
fi
echo
echo "Next:  git push origin latiffa"
echo "Then open GitHub -> 'Compare & pull request' -> paste PR_DESCRIPTION.md -> ask a teammate to review."
