# Google Form answers: Checkpoint 1 (submit ONCE for the group)

Fill in any field the form asks for that isn't listed here, such as the group number.

**Project title:** The Last Clue

**Brief description:**
An interactive 2D detective puzzle game. The player investigates a crime scene, solves graphical puzzles (a safe dial, a torn letter, an evidence board) and deduces who committed the crime, how and why. The graphics are the investigation tools: rotating the dial, moving and rotating torn pieces, and connecting clues with strings are all graphics operations.

**Group members and responsibilities:**
- Caleb Kipchirchir (Graphics & Algorithms): Canvas/BMP core, DDA & Bresenham lines, midpoint circle & ellipse, 2D transformation matrices, integration
- Alvin Kimani (Environment & Visual Design): polygon representation, scanline fill (edge table/AET), flood & boundary fill, crime scene, characters
- Sudheysi Ali (Puzzles & Game Mechanics): Cohen–Sutherland and Sutherland–Hodgman clipping, point-in-polygon, safe dial, torn letter puzzle, viewport/magnifier clipping
- Latiffa (Interface, Animation & Integration): Bézier (de Casteljau) and Catmull-Rom curves, evidence board, Case File panel, documentation

**GitHub repository:** https://github.com/C-Sawe/the-last-clue

**Technologies/tools:** C++17 (no graphics library: every pixel is drawn by our own algorithms), CMake, Git/GitHub (branches per member, issues, milestones, pull requests). We write 24-bit BMP images with our own encoder.

**Graphics techniques/algorithms implemented so far:**
- Lines: DDA, Bresenham (all 8 octants), thick lines
- Polygons: vertex-list representation; scanline fill with edge table + active edge table (convex and concave); flood fill and boundary fill
- Clipping: Cohen–Sutherland line clipping, Sutherland–Hodgman polygon clipping; point-in-polygon (ray casting)
- Circles and ellipses: midpoint circle (8-way symmetry), midpoint ellipse (regions 1 and 2), filled versions
- Curves: Bézier curves via de Casteljau (any degree), Catmull-Rom splines
- Early start on CP2: 2D transformations with 3×3 homogeneous matrices (translate, rotate/scale about a pivot, composite, inverse)

**How the techniques relate to the project:**
- Crime scene furniture and the room: polygons with scanline fill
- Characters: ellipse heads, polygon coats, arms rotated about the shoulder
- Safe dial: circles, plus ticks rotated about the dial centre
- Torn letter puzzle: irregular polygons, transforms and point-in-polygon
- Evidence board: sagging Bézier strings, Catmull-Rom handwriting, circle pins
- Clipping: the scene viewport and the magnifying glass

**Current progress:**
All Checkpoint 1 algorithms are implemented and applied to game components: crime scene, character line-up, safe dial, torn letter puzzle, evidence board, Case File panel and the full game layout. There are 16 demo programs, each producing an image. Work is tracked in 27 CP1 issues, with milestones planned for CP2, CP3 and the final project.

**Known limitations:**
- Output is static images: there is no window, input or animation yet (CP2/CP3).
- Text is upper-case only (our own 5×7 bitmap font) and does not rotate.
- There is no anti-aliasing yet.

**Evidence upload:** `docs/checkpoint1_screenshots.pdf` (cover page and 16 captioned screenshots). For object/character images, also upload `docs/screenshots/11_characters.png`, `10_crime_scene.png` and `15_evidence_board.png` if the form asks for them separately.
