## CP1: README, screenshots and evidence PDF (Latiffa)

Final Checkpoint 1 documentation: README with every required section, PNG screenshots in `docs/screenshots/`, and `docs/checkpoint1_screenshots.pdf` for the Google Form.

Closes #26
Closes #27
