# Latiffa: Checkpoint 1 work, explained

You own **curves** (Bézier and Catmull-Rom), the **evidence board**, the **Case File panel**, and the **README, PDF and Google Form**. Read this before submission, because the lecturer may ask you to explain it.

## 1. Bézier curves: de Casteljau (`src/curves/bezier.cpp`, issue #22)
- Start with the control points P0…Pn.
- Interpolate each neighbouring pair at t: `(1-t)·Pi + t·Pi+1`. That gives n points. Repeat until only **one point** is left; that point is B(t).
- This works for **any degree** and is numerically stable. The demo shows quadratic, cubic and degree-5 curves.
- To draw the curve, sample t at 0, 1/N, 2/N, …, 1 and join the samples with **Bresenham** lines.
- The curve passes through **only the first and last** control points. The middle points pull the curve towards them without touching it.
- **Evidence strings:** a quadratic curve between two pins. The middle control point is the midpoint pushed down by `0.18 × distance`, so longer strings sag more, as real string does.

## 2. Catmull-Rom spline (`src/curves/spline.cpp`, issue #23)
- Unlike Bézier, a Catmull-Rom spline **passes through every point**, which is what handwriting needs.
- Each span from P1 to P2 also uses the neighbours P0 and P3:
  `C(t) = 0.5·[2P1 + (−P0+P2)t + (2P0−5P1+4P2−P3)t² + (−P0+3P1−3P2+P3)t³]`
- The first and last points are duplicated so the curve reaches both ends.
- The demo draws Bézier and Catmull-Rom on the **same points** to show the difference. It also draws a suspect's signature.

## 3. Evidence board (`src/scenes/evidence_board.cpp`, issue #24)
- **Cork texture:** a filled rectangle plus about 6,000 speckle pixels from a fixed pseudo-random sequence, so the image is the same every run.
- **Cards and photos:** filled rectangles with an offset dark rectangle as a shadow. The suspect photos use ellipses for the head and shoulders, in each suspect's colour.
- **Sticky notes** are rotated with `rotateAbout`. Their scribble is a Catmull-Rom curve whose points go through **the same matrix**, so the writing tilts with the paper.
- **Pins:** filled circles with a small white highlight.
- **Strings:** sagging quadratic Bézier curves, drawn twice one pixel apart so they look thicker. Red connects the victim to the suspects; blue and green link clues.
- **Fingerprint:** concentric midpoint ellipses.

## 4. Case File panel (`src/scenes/case_file.cpp`, issue #25)
- This is the left side of the game window:
  - Suspects, each with a colour badge (a circle with a tiny ellipse person inside).
  - Evidence slots: filled with an icon when collected, a dashed outline when empty.
  - Buttons for the evidence board and the deduction.
- `16_full_layout` puts the panel next to Alvin's crime scene, using `Canvas::blit`. That is the planned main screen.

## 5. Documentation and submission (issues #26, #27)
- `README.md` contains every section Checkpoint 1 asks for: title, description, members and roles, tools, algorithms, build and run instructions, progress, and limitations. It also has a screenshot gallery.
- `docs/checkpoint1_screenshots.pdf` has a cover page, then one page per image (16 in total), each with a caption saying which algorithm it shows and who implemented it.
- **You submit the Google Form, once, for the whole group.** The answers are ready in `GOOGLE_FORM_ANSWERS.md`.

## Questions you might get
- *Why does the Bézier curve not touch its middle control points?* The curve is a weighted average of all the control points. Only at t=0 and t=1 does a single point get all the weight.
- *Why Catmull-Rom for handwriting?* It interpolates the points, so the pen passes exactly where we place them.
- *How do you draw a curve with pixels?* By sampling it at many values of t and joining consecutive samples with Bresenham lines.

## How to submit (two steps)
1. Set your identity, using the email on your GitHub account (latifahjaafar):
   `git config --global user.name "Latiffa"` and `git config --global user.email "<your github email>"`
2. **Accept the collaborator invite** on GitHub, if you haven't yet.
3. **After Alvin's PR is merged**, in your clone of the repo, run:
   `bash ../latiffa-cp1/commit_my_work.sh`
   Then `git push origin latiffa` and open a pull request with `PR_DESCRIPTION.md`.
4. **After Sudheysi's PR is merged too**, run:
   `bash ../latiffa-cp1/commit_my_work.sh docs`
   Then `git push origin latiffa` and open a second pull request with `PR_DESCRIPTION_DOCS.md`.
5. Submit the Google Form **once**, using `GOOGLE_FORM_ANSWERS.md` and uploading `docs/checkpoint1_screenshots.pdf`.
